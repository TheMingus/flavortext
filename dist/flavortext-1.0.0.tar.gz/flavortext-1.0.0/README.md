# flavortext.py
I shamelessly yoinked this from [ZachFreedman's Singularitron](https://github.com/ZackFreedman/Singularitron) project, and rewrote it in Python.

sue me.

## How to use:
import the module:
`from flavortext import flavoricious`

The flavoricious function can take 6 arguments:

`yourConstrVerbs`: A list, verbs that are constructive such as 'Building' or 'Assembling'.
`yourDestrVerbs`: A list, verbs that are destructive such as 'Destroying' or 'Breaking'.
*Note for both of these args: Make sure to remove any sort of ending like 'ing' from the words you provide.
yourNouns = None,
length = 30,
delay = 0.05`